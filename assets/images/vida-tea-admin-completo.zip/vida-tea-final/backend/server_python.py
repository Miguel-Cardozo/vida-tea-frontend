"""
VIDA TEA - API do painel administrativo (versão Python/Flask)
=============================================================
Implementa as mesmas rotas do servidor Node.js original, mas usando:
  - Python + Flask  (no lugar de Node.js + Express)
  - SQLite          (no lugar de MySQL, para rodar sem instalação extra)
  - PyJWT           (tokens de acesso, igual ao jsonwebtoken do Node)
  - Werkzeug        (hash de senha, compatível com bcryptjs do Node)

As rotas são idênticas às do Node. O frontend React não precisa
de nenhuma alteração — ele nem sabe que o servidor mudou.
"""

import os
import sqlite3
import datetime
import threading

from flask import Flask, request, jsonify, g
import jwt
from werkzeug.security import generate_password_hash, check_password_hash

# ─────────────────────────────────────────────
# Configurações (equivale ao .env do Node)
# ─────────────────────────────────────────────
PORT       = int(os.environ.get("PORT", 3001))
DB_PATH    = os.environ.get("DB_PATH", os.path.join(os.path.dirname(__file__), "vida_tea.db"))
JWT_SECRET = os.environ.get("JWT_SECRET", "troque-esta-chave-por-um-texto-aleatorio")

ADMIN_NOME  = os.environ.get("ADMIN_NOME",  "Equipe VIDA TEA")
ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "admin@vidatea.com")
ADMIN_SENHA = os.environ.get("ADMIN_SENHA", "vidatea123")

app = Flask(__name__)

# ─────────────────────────────────────────────
# Banco de dados: conexão por thread (SQLite)
# ─────────────────────────────────────────────

def get_db():
    """Retorna a conexão do banco para a thread atual."""
    if not hasattr(g, "_db"):
        g._db = sqlite3.connect(DB_PATH)
        g._db.row_factory = sqlite3.Row   # permite acessar colunas pelo nome
        g._db.execute("PRAGMA journal_mode=WAL")  # melhora concorrência
    return g._db

@app.teardown_appcontext
def fechar_db(exc):
    """Fecha a conexão ao terminar cada requisição."""
    db = getattr(g, "_db", None)
    if db is not None:
        db.close()


def inicializar_banco():
    """
    Cria as tabelas no SQLite (equivale ao schema.sql do MySQL).
    Executa uma só vez ao iniciar o servidor.
    """
    conn = sqlite3.connect(DB_PATH)
    cur  = conn.cursor()

    # Tabela de administradores
    cur.execute("""
        CREATE TABLE IF NOT EXISTS administradores (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            nome      TEXT    NOT NULL,
            email     TEXT    NOT NULL UNIQUE,
            senha_hash TEXT   NOT NULL,
            criado_em TEXT    NOT NULL DEFAULT (datetime('now'))
        )
    """)

    # Tabela de postagens
    cur.execute("""
        CREATE TABLE IF NOT EXISTS postagens (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo        TEXT    NOT NULL,
            conteudo      TEXT    NOT NULL,
            tipo          TEXT    NOT NULL DEFAULT 'TEXTO',
            url_midia     TEXT,
            autor_id      INTEGER,
            publicado_em  TEXT    NOT NULL DEFAULT (datetime('now')),
            atualizado_em TEXT    NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (autor_id) REFERENCES administradores(id) ON DELETE SET NULL
        )
    """)

    # Tabela de dúvidas
    cur.execute("""
        CREATE TABLE IF NOT EXISTS duvidas (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_nome   TEXT    NOT NULL,
            usuario_email  TEXT,
            mensagem       TEXT    NOT NULL,
            resposta       TEXT,
            status         TEXT    NOT NULL DEFAULT 'pendente',
            criado_em      TEXT    NOT NULL DEFAULT (datetime('now')),
            respondido_em  TEXT,
            respondido_por INTEGER,
            FOREIGN KEY (respondido_por) REFERENCES administradores(id) ON DELETE SET NULL
        )
    """)

    conn.commit()

    # Insere dúvidas de exemplo se a tabela estiver vazia
    count = conn.execute("SELECT COUNT(*) FROM duvidas").fetchone()[0]
    if count == 0:
        cur.executemany(
            "INSERT INTO duvidas (usuario_nome, usuario_email, mensagem) VALUES (?, ?, ?)",
            [
                ("Maria Silva",  "maria@exemplo.com", "Como faço para solicitar o cartão de estacionamento para meu filho?"),
                ("João Pereira", "joao@exemplo.com",  "Quais documentos preciso para o BPC/LOAS?"),
            ]
        )
        conn.commit()

    conn.close()


def garantir_admin_padrao():
    """
    Cria um administrador padrão se ainda não existir nenhum.
    (Mesma lógica do garantirAdminPadrao() no server.js do Node.)
    """
    conn = sqlite3.connect(DB_PATH)
    total = conn.execute("SELECT COUNT(*) FROM administradores").fetchone()[0]
    if total == 0:
        hash_senha = generate_password_hash(ADMIN_SENHA)
        conn.execute(
            "INSERT INTO administradores (nome, email, senha_hash) VALUES (?, ?, ?)",
            (ADMIN_NOME, ADMIN_EMAIL, hash_senha)
        )
        conn.commit()
        print("--------------------------------------------------")
        print("Administrador padrão criado:")
        print(f"  E-mail: {ADMIN_EMAIL}")
        print(f"  Senha : {ADMIN_SENHA}")
        print("Troque a senha na tela de Configurações após entrar.")
        print("--------------------------------------------------")
    conn.close()


# ─────────────────────────────────────────────
# CORS manual (equivale ao cors() do Express)
# ─────────────────────────────────────────────

@app.after_request
def adicionar_cors(response):
    """Permite que o frontend (Vite, porta 5173) acesse a API."""
    response.headers["Access-Control-Allow-Origin"]  = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    return response

@app.route("/api/<path:p>", methods=["OPTIONS"])
@app.route("/", methods=["OPTIONS"])
def preflight(p=""):
    """Responde ao preflight CORS do navegador."""
    return "", 204


# ─────────────────────────────────────────────
# Middleware de autenticação JWT
# ─────────────────────────────────────────────

def autenticar():
    """
    Lê o token Bearer do cabeçalho Authorization e devolve os dados
    do admin. Retorna None se o token estiver ausente ou inválido.
    (Equivale ao middleware auth.js do Node.)
    """
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None, jsonify({"erro": "Faça login para continuar."}), 401

    token = header[7:]
    try:
        dados = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        return dados, None, None
    except jwt.ExpiredSignatureError:
        return None, jsonify({"erro": "Sessão expirada. Faça login novamente."}), 401
    except Exception:
        return None, jsonify({"erro": "Sessão expirada. Faça login novamente."}), 401


# ─────────────────────────────────────────────
# Rota raiz (health check)
# ─────────────────────────────────────────────

@app.route("/")
def raiz():
    return jsonify({"servico": "VIDA TEA - API do painel", "ok": True})


# ─────────────────────────────────────────────
# UC002 - Autenticação  →  /api/auth/login
# ─────────────────────────────────────────────

@app.route("/api/auth/login", methods=["POST"])
def login():
    """
    Recebe e-mail e senha, valida e devolve um token JWT.
    (Equivale a routes/auth.js no Node.)
    """
    corpo = request.get_json() or {}
    email = corpo.get("email", "").strip()
    senha = corpo.get("senha", "")

    if not email or not senha:
        return jsonify({"erro": "Informe e-mail e senha."}), 400

    db  = get_db()
    row = db.execute(
        "SELECT id, nome, email, senha_hash FROM administradores WHERE email = ?",
        (email,)
    ).fetchone()

    if not row or not check_password_hash(row["senha_hash"], senha):
        return jsonify({"erro": "E-mail ou senha incorretos."}), 401

    # Cria o token JWT com 8 horas de validade
    payload = {
        "id":    row["id"],
        "nome":  row["nome"],
        "email": row["email"],
        "exp":   datetime.datetime.utcnow() + datetime.timedelta(hours=8),
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm="HS256")
    admin = {"id": row["id"], "nome": row["nome"], "email": row["email"]}

    return jsonify({"token": token, "admin": admin})


# ─────────────────────────────────────────────
# UC003 / UC005 / UC006 - Postagens  →  /api/posts
# ─────────────────────────────────────────────

@app.route("/api/posts", methods=["GET"])
def listar_posts():
    """
    Lista todas as postagens. Aceita ?busca=termo para filtrar pelo título.
    Rota protegida (precisa de login).
    (Equivale ao GET / em routes/posts.js no Node.)
    """
    admin, erro_resp, status = autenticar()
    if erro_resp:
        return erro_resp, status

    busca = request.args.get("busca", "").strip()
    db    = get_db()

    if busca:
        sql    = "SELECT id, titulo, conteudo, tipo, url_midia, publicado_em, atualizado_em FROM postagens WHERE titulo LIKE ? ORDER BY publicado_em DESC"
        linhas = db.execute(sql, (f"%{busca}%",)).fetchall()
    else:
        sql    = "SELECT id, titulo, conteudo, tipo, url_midia, publicado_em, atualizado_em FROM postagens ORDER BY publicado_em DESC"
        linhas = db.execute(sql).fetchall()

    return jsonify([dict(r) for r in linhas])


@app.route("/api/posts/publicas", methods=["GET"])
def posts_publicos():
    """
    ROTA PÚBLICA — sem necessidade de login.
    O aplicativo das famílias usa esta rota para exibir a Central de Informações.
    Devolve id, titulo, conteudo, tipo, url_midia e data de publicação.
    (Nova rota, pedida no item 4 do briefing.)
    """
    db    = get_db()
    linhas = db.execute(
        "SELECT id, titulo, conteudo, tipo, url_midia, publicado_em FROM postagens ORDER BY publicado_em DESC"
    ).fetchall()
    return jsonify([dict(r) for r in linhas])


@app.route("/api/posts/<int:post_id>", methods=["GET"])
def buscar_post(post_id):
    """
    Retorna uma postagem pelo ID.
    Rota protegida.
    """
    admin, erro_resp, status = autenticar()
    if erro_resp:
        return erro_resp, status

    db  = get_db()
    row = db.execute("SELECT * FROM postagens WHERE id = ?", (post_id,)).fetchone()
    if not row:
        return jsonify({"erro": "Postagem não encontrada."}), 404
    return jsonify(dict(row))


@app.route("/api/posts", methods=["POST"])
def criar_post():
    """
    UC003 - Cria uma nova postagem.
    Rota protegida.
    """
    admin, erro_resp, status = autenticar()
    if erro_resp:
        return erro_resp, status

    corpo = request.get_json() or {}
    titulo   = (corpo.get("titulo")   or "").strip()
    conteudo = (corpo.get("conteudo") or "").strip()
    tipo     = corpo.get("tipo", "TEXTO")
    url      = corpo.get("url_midia") or None

    if not titulo or not conteudo:
        return jsonify({"erro": "Preencha o título e o conteúdo."}), 400

    db = get_db()
    cur = db.execute(
        "INSERT INTO postagens (titulo, conteudo, tipo, url_midia, autor_id) VALUES (?, ?, ?, ?, ?)",
        (titulo, conteudo, tipo, url, admin["id"])
    )
    db.commit()
    return jsonify({"id": cur.lastrowid}), 201


@app.route("/api/posts/<int:post_id>", methods=["PUT"])
def editar_post(post_id):
    """
    UC005 - Edita uma postagem existente.
    Rota protegida.
    """
    admin, erro_resp, status = autenticar()
    if erro_resp:
        return erro_resp, status

    corpo = request.get_json() or {}
    titulo   = (corpo.get("titulo")   or "").strip()
    conteudo = (corpo.get("conteudo") or "").strip()
    tipo     = corpo.get("tipo", "TEXTO")
    url      = corpo.get("url_midia") or None

    if not titulo or not conteudo:
        return jsonify({"erro": "Preencha o título e o conteúdo."}), 400

    db = get_db()
    cur = db.execute(
        "UPDATE postagens SET titulo=?, conteudo=?, tipo=?, url_midia=?, atualizado_em=datetime('now') WHERE id=?",
        (titulo, conteudo, tipo, url, post_id)
    )
    db.commit()

    if cur.rowcount == 0:
        return jsonify({"erro": "Postagem não encontrada."}), 404
    return jsonify({"ok": True})


@app.route("/api/posts/<int:post_id>", methods=["DELETE"])
def excluir_post(post_id):
    """
    UC005 - Exclui uma postagem.
    Rota protegida.
    """
    admin, erro_resp, status = autenticar()
    if erro_resp:
        return erro_resp, status

    db = get_db()
    db.execute("DELETE FROM postagens WHERE id = ?", (post_id,))
    db.commit()
    return jsonify({"ok": True})


# ─────────────────────────────────────────────
# UC004 - Dúvidas  →  /api/doubts
# ─────────────────────────────────────────────

@app.route("/api/doubts", methods=["GET"])
def listar_duvidas():
    """
    Lista as dúvidas. Aceita ?status=pendente|respondida.
    Rota protegida.
    (Equivale ao GET / em routes/doubts.js no Node.)
    """
    admin, erro_resp, status = autenticar()
    if erro_resp:
        return erro_resp, status

    filtro = request.args.get("status", "")
    db     = get_db()

    if filtro in ("pendente", "respondida"):
        sql    = "SELECT * FROM duvidas WHERE status = ? ORDER BY (status = 'pendente') DESC, criado_em DESC"
        linhas = db.execute(sql, (filtro,)).fetchall()
    else:
        sql    = "SELECT * FROM duvidas ORDER BY (status = 'pendente') DESC, criado_em DESC"
        linhas = db.execute(sql).fetchall()

    return jsonify([dict(r) for r in linhas])


@app.route("/api/doubts", methods=["POST"])
def enviar_duvida():
    """
    ROTA PÚBLICA — o aplicativo das famílias usa esta rota para enviar perguntas.
    Não exige login.
    (Equivale ao POST / público em routes/doubts.js no Node.)
    """
    corpo  = request.get_json() or {}
    nome   = (corpo.get("usuario_nome") or "").strip()
    email  = corpo.get("usuario_email") or None
    msg    = (corpo.get("mensagem") or "").strip()

    if not nome or not msg:
        return jsonify({"erro": "Informe o nome e a mensagem."}), 400

    db  = get_db()
    cur = db.execute(
        "INSERT INTO duvidas (usuario_nome, usuario_email, mensagem) VALUES (?, ?, ?)",
        (nome, email, msg)
    )
    db.commit()
    return jsonify({"id": cur.lastrowid}), 201


@app.route("/api/doubts/<int:duvida_id>/responder", methods=["POST"])
def responder_duvida(duvida_id):
    """
    UC004 - Salva a resposta de uma dúvida e muda o status para 'respondida'.
    Rota protegida.
    """
    admin, erro_resp, status = autenticar()
    if erro_resp:
        return erro_resp, status

    corpo   = request.get_json() or {}
    resposta = (corpo.get("resposta") or "").strip()
    if not resposta:
        return jsonify({"erro": "Escreva a resposta."}), 400

    db  = get_db()
    cur = db.execute(
        """UPDATE duvidas
           SET resposta = ?, status = 'respondida',
               respondido_em = datetime('now'), respondido_por = ?
           WHERE id = ?""",
        (resposta, admin["id"], duvida_id)
    )
    db.commit()

    if cur.rowcount == 0:
        return jsonify({"erro": "Dúvida não encontrada."}), 404
    return jsonify({"ok": True})


# ─────────────────────────────────────────────
# Dashboard e Perfil  →  /api/dashboard, /api/profile
# ─────────────────────────────────────────────

@app.route("/api/dashboard", methods=["GET"])
def dashboard():
    """
    Retorna os indicadores do painel inicial.
    Rota protegida.
    (Equivale ao GET /dashboard em routes/account.js no Node.)
    """
    admin, erro_resp, status = autenticar()
    if erro_resp:
        return erro_resp, status

    db = get_db()

    total_posts    = db.execute("SELECT COUNT(*) FROM postagens").fetchone()[0]
    por_tipo       = db.execute("SELECT tipo, COUNT(*) AS total FROM postagens GROUP BY tipo").fetchall()
    pendentes      = db.execute("SELECT COUNT(*) FROM duvidas WHERE status = 'pendente'").fetchone()[0]
    respondidas    = db.execute("SELECT COUNT(*) FROM duvidas WHERE status = 'respondida'").fetchone()[0]
    administradores = db.execute("SELECT COUNT(*) FROM administradores").fetchone()[0]

    return jsonify({
        "postagens":          total_posts,
        "postagensPorTipo":   [{"tipo": r[0], "total": r[1]} for r in por_tipo],
        "duvidasPendentes":   pendentes,
        "duvidasRespondidas": respondidas,
        "administradores":    administradores,
    })


@app.route("/api/profile", methods=["PUT"])
def atualizar_perfil():
    """
    UC007 - Atualiza nome, e-mail e/ou senha do administrador logado.
    Rota protegida.
    (Equivale ao PUT /profile em routes/account.js no Node.)
    """
    admin_token, erro_resp, status = autenticar()
    if erro_resp:
        return erro_resp, status

    corpo      = request.get_json() or {}
    nome       = corpo.get("nome", "").strip()
    email      = corpo.get("email", "").strip()
    senha_atual = corpo.get("senhaAtual", "")
    nova_senha  = corpo.get("novaSenha", "")

    db  = get_db()
    row = db.execute(
        "SELECT * FROM administradores WHERE id = ?",
        (admin_token["id"],)
    ).fetchone()

    if not row:
        return jsonify({"erro": "Conta não encontrada."}), 404

    senha_hash = row["senha_hash"]

    # Só troca a senha se o usuário preencheu os campos
    if nova_senha:
        if not check_password_hash(senha_hash, senha_atual):
            return jsonify({"erro": "A senha atual está incorreta."}), 400
        senha_hash = generate_password_hash(nova_senha)

    db.execute(
        "UPDATE administradores SET nome=?, email=?, senha_hash=? WHERE id=?",
        (nome or row["nome"], email or row["email"], senha_hash, admin_token["id"])
    )
    db.commit()
    return jsonify({"ok": True})


# ─────────────────────────────────────────────
# Inicialização
# ─────────────────────────────────────────────

if __name__ == "__main__":
    # Cria tabelas e admin padrão antes de aceitar requisições
    inicializar_banco()
    garantir_admin_padrao()

    print(f"API do VIDA TEA rodando em http://localhost:{PORT}")
    app.run(host="0.0.0.0", port=PORT, debug=False)
