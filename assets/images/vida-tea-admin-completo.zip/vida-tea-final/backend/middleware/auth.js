const jwt = require("jsonwebtoken");

// Verifica o token enviado no cabecalho Authorization: Bearer <token>.
function autenticar(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ erro: "Faca login para continuar." });
  }

  try {
    const dados = jwt.verify(token, process.env.JWT_SECRET || "segredo");
    req.admin = dados; // { id, nome, email }
    next();
  } catch (e) {
    return res.status(401).json({ erro: "Sessao expirada. Faca login novamente." });
  }
}

module.exports = autenticar;
