const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const pool = require("../db");

const router = express.Router();

// UC002 - Fazer login
router.post("/login", async (req, res) => {
  const { email, senha } = req.body || {};
  if (!email || !senha) {
    return res.status(400).json({ erro: "Informe e-mail e senha." });
  }

  try {
    const [linhas] = await pool.query(
      "SELECT id, nome, email, senha_hash FROM administradores WHERE email = ?",
      [email]
    );
    const admin = linhas[0];
    if (!admin) {
      return res.status(401).json({ erro: "E-mail ou senha incorretos." });
    }

    const ok = await bcrypt.compare(senha, admin.senha_hash);
    if (!ok) {
      return res.status(401).json({ erro: "E-mail ou senha incorretos." });
    }

    const payload = { id: admin.id, nome: admin.nome, email: admin.email };
    const token = jwt.sign(payload, process.env.JWT_SECRET || "segredo", {
      expiresIn: "8h",
    });

    res.json({ token, admin: payload });
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: "Erro ao acessar o servidor." });
  }
});

module.exports = router;
