const express = require("express");
const bcrypt = require("bcryptjs");
const pool = require("../db");
const autenticar = require("../middleware/auth");

const router = express.Router();

// Indicadores do painel inicial (dashboard)
router.get("/dashboard", autenticar, async (req, res) => {
  try {
    const [[postagens]] = await pool.query(
      "SELECT COUNT(*) AS total FROM postagens"
    );
    const [porTipo] = await pool.query(
      "SELECT tipo, COUNT(*) AS total FROM postagens GROUP BY tipo"
    );
    const [[pendentes]] = await pool.query(
      "SELECT COUNT(*) AS total FROM duvidas WHERE status = 'pendente'"
    );
    const [[respondidas]] = await pool.query(
      "SELECT COUNT(*) AS total FROM duvidas WHERE status = 'respondida'"
    );
    const [[admins]] = await pool.query(
      "SELECT COUNT(*) AS total FROM administradores"
    );
    res.json({
      postagens: postagens.total,
      postagensPorTipo: porTipo,
      duvidasPendentes: pendentes.total,
      duvidasRespondidas: respondidas.total,
      administradores: admins.total,
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: "Nao foi possivel carregar os indicadores." });
  }
});

// UC007 - Fazer atualizacoes (perfil e senha)
router.put("/profile", autenticar, async (req, res) => {
  const { nome, email, senhaAtual, novaSenha } = req.body || {};
  try {
    const [linhas] = await pool.query(
      "SELECT * FROM administradores WHERE id = ?",
      [req.admin.id]
    );
    const admin = linhas[0];
    if (!admin) return res.status(404).json({ erro: "Conta nao encontrada." });

    let senhaHash = admin.senha_hash;
    if (novaSenha) {
      const ok = await bcrypt.compare(senhaAtual || "", admin.senha_hash);
      if (!ok) return res.status(400).json({ erro: "A senha atual esta incorreta." });
      senhaHash = await bcrypt.hash(novaSenha, 10);
    }

    await pool.query(
      "UPDATE administradores SET nome = ?, email = ?, senha_hash = ? WHERE id = ?",
      [nome || admin.nome, email || admin.email, senhaHash, req.admin.id]
    );
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: "Nao foi possivel salvar as alteracoes." });
  }
});

module.exports = router;
