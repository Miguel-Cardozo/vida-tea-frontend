const express = require("express");
const pool = require("../db");
const autenticar = require("../middleware/auth");

const router = express.Router();

// -------------------------------------------------------
// ROTA PÚBLICA — sem necessidade de login.
// O aplicativo das famílias usa esta rota para exibir
// a Central de Informações sem precisar fazer login.
// Exemplo: GET http://localhost:3001/api/posts/publicas
// -------------------------------------------------------
router.get("/publicas", async (req, res) => {
  try {
    const [linhas] = await pool.query(
      "SELECT id, titulo, conteudo, tipo, url_midia, publicado_em FROM postagens ORDER BY publicado_em DESC"
    );
    res.json(linhas);
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: "Não foi possível carregar as postagens." });
  }
});

// UC003/UC005/UC006 - listar e buscar postagens
// Aceita ?busca=termo para pesquisar pelo titulo.
router.get("/", autenticar, async (req, res) => {
  const busca = (req.query.busca || "").trim();
  try {
    let sql =
      "SELECT id, titulo, conteudo, tipo, url_midia, publicado_em, atualizado_em FROM postagens";
    const params = [];
    if (busca) {
      sql += " WHERE titulo LIKE ?";
      params.push(`%${busca}%`);
    }
    sql += " ORDER BY publicado_em DESC";
    const [linhas] = await pool.query(sql, params);
    res.json(linhas);
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: "Nao foi possivel carregar as postagens." });
  }
});

// Buscar uma postagem
router.get("/:id", autenticar, async (req, res) => {
  try {
    const [linhas] = await pool.query("SELECT * FROM postagens WHERE id = ?", [
      req.params.id,
    ]);
    if (!linhas[0]) return res.status(404).json({ erro: "Postagem nao encontrada." });
    res.json(linhas[0]);
  } catch (e) {
    res.status(500).json({ erro: "Erro ao carregar a postagem." });
  }
});

// UC003 - Fazer postagem
router.post("/", autenticar, async (req, res) => {
  const { titulo, conteudo, tipo, url_midia } = req.body || {};
  if (!titulo || !conteudo) {
    return res.status(400).json({ erro: "Preencha o titulo e o conteudo." });
  }
  try {
    const [r] = await pool.query(
      "INSERT INTO postagens (titulo, conteudo, tipo, url_midia, autor_id) VALUES (?, ?, ?, ?, ?)",
      [titulo, conteudo, tipo || "TEXTO", url_midia || null, req.admin.id]
    );
    res.status(201).json({ id: r.insertId });
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: "Nao foi possivel salvar a postagem." });
  }
});

// UC005 - Editar publicacoes
router.put("/:id", autenticar, async (req, res) => {
  const { titulo, conteudo, tipo, url_midia } = req.body || {};
  if (!titulo || !conteudo) {
    return res.status(400).json({ erro: "Preencha o titulo e o conteudo." });
  }
  try {
    const [r] = await pool.query(
      "UPDATE postagens SET titulo = ?, conteudo = ?, tipo = ?, url_midia = ? WHERE id = ?",
      [titulo, conteudo, tipo || "TEXTO", url_midia || null, req.params.id]
    );
    if (r.affectedRows === 0)
      return res.status(404).json({ erro: "Postagem nao encontrada." });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ erro: "Nao foi possivel atualizar a postagem." });
  }
});

// UC005 - Excluir publicacao
router.delete("/:id", autenticar, async (req, res) => {
  try {
    await pool.query("DELETE FROM postagens WHERE id = ?", [req.params.id]);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ erro: "Nao foi possivel excluir a postagem." });
  }
});

module.exports = router;
