const express = require("express");
const pool = require("../db");
const autenticar = require("../middleware/auth");

const router = express.Router();

// UC004 - listar duvidas (opcional ?status=pendente|respondida)
router.get("/", autenticar, async (req, res) => {
  const status = req.query.status;
  try {
    let sql = "SELECT * FROM duvidas";
    const params = [];
    if (status === "pendente" || status === "respondida") {
      sql += " WHERE status = ?";
      params.push(status);
    }
    sql += " ORDER BY (status = 'pendente') DESC, criado_em DESC";
    const [linhas] = await pool.query(sql, params);
    res.json(linhas);
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: "Nao foi possivel carregar as duvidas." });
  }
});

// Rota PUBLICA: o aplicativo das familias usa esta rota para enviar uma duvida.
// (Nao exige login, pois quem envia e o usuario do app.)
router.post("/", async (req, res) => {
  const { usuario_nome, usuario_email, mensagem } = req.body || {};
  if (!usuario_nome || !mensagem) {
    return res.status(400).json({ erro: "Informe o nome e a mensagem." });
  }
  try {
    const [r] = await pool.query(
      "INSERT INTO duvidas (usuario_nome, usuario_email, mensagem) VALUES (?, ?, ?)",
      [usuario_nome, usuario_email || null, mensagem]
    );
    res.status(201).json({ id: r.insertId });
  } catch (e) {
    res.status(500).json({ erro: "Nao foi possivel enviar a mensagem." });
  }
});

// UC004 - Responder duvida
router.post("/:id/responder", autenticar, async (req, res) => {
  const { resposta } = req.body || {};
  if (!resposta) return res.status(400).json({ erro: "Escreva a resposta." });
  try {
    const [r] = await pool.query(
      "UPDATE duvidas SET resposta = ?, status = 'respondida', respondido_em = NOW(), respondido_por = ? WHERE id = ?",
      [resposta, req.admin.id, req.params.id]
    );
    if (r.affectedRows === 0)
      return res.status(404).json({ erro: "Duvida nao encontrada." });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ erro: "Nao foi possivel salvar a resposta." });
  }
});

module.exports = router;
