// Cria/atualiza um administrador a partir das variaveis do .env.
// Uso: npm run seed
const bcrypt = require("bcryptjs");
const pool = require("../db");
require("dotenv").config();

(async () => {
  try {
    const nome = process.env.ADMIN_NOME || "Equipe VIDA TEA";
    const email = process.env.ADMIN_EMAIL || "admin@vidatea.com";
    const senha = process.env.ADMIN_SENHA || "vidatea123";
    const hash = await bcrypt.hash(senha, 10);

    await pool.query(
      `INSERT INTO administradores (nome, email, senha_hash)
       VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE nome = VALUES(nome), senha_hash = VALUES(senha_hash)`,
      [nome, email, hash]
    );
    console.log("Administrador pronto:", email, "/ senha:", senha);
    process.exit(0);
  } catch (e) {
    console.error("Erro ao criar administrador:", e.message);
    process.exit(1);
  }
})();
