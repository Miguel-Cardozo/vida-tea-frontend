-- =============================================================
--  VIDA TEA - Banco de dados do painel administrativo
--  Execute este arquivo no MySQL antes de iniciar a API:
--    mysql -u root -p < schema.sql
--  (ou rode o conteudo no MySQL Workbench)
-- =============================================================

CREATE DATABASE IF NOT EXISTS vida_tea
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE vida_tea;

-- Administradores (integrantes do grupo que acessam o painel)
CREATE TABLE IF NOT EXISTS administradores (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  nome        VARCHAR(120) NOT NULL,
  email       VARCHAR(160) NOT NULL UNIQUE,
  senha_hash  VARCHAR(255) NOT NULL,
  criado_em   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Postagens exibidas na Central de Informacoes do aplicativo
CREATE TABLE IF NOT EXISTS postagens (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  titulo        VARCHAR(200) NOT NULL,
  conteudo      TEXT NOT NULL,
  tipo          ENUM('TEXTO','PDF','VIDEO') NOT NULL DEFAULT 'TEXTO',
  url_midia     VARCHAR(500) NULL,
  autor_id      INT NULL,
  publicado_em  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_postagem_autor FOREIGN KEY (autor_id)
    REFERENCES administradores(id) ON DELETE SET NULL
);

-- Duvidas/mensagens enviadas pelos usuarios do aplicativo
CREATE TABLE IF NOT EXISTS duvidas (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  usuario_nome   VARCHAR(120) NOT NULL,
  usuario_email  VARCHAR(160) NULL,
  mensagem       TEXT NOT NULL,
  resposta       TEXT NULL,
  status         ENUM('pendente','respondida') NOT NULL DEFAULT 'pendente',
  criado_em      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  respondido_em  DATETIME NULL,
  respondido_por INT NULL,
  CONSTRAINT fk_duvida_admin FOREIGN KEY (respondido_por)
    REFERENCES administradores(id) ON DELETE SET NULL
);

-- Alguns exemplos de duvidas para visualizar a tela de atendimento.
-- (Pode apagar estas linhas quando integrar com o aplicativo.)
INSERT INTO duvidas (usuario_nome, usuario_email, mensagem) VALUES
  ('Maria Silva', 'maria@exemplo.com', 'Como faco para solicitar o cartao de estacionamento para meu filho?'),
  ('Joao Pereira', 'joao@exemplo.com', 'Quais documentos preciso para o BPC/LOAS?');
