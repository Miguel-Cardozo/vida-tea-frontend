const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
require("dotenv").config();

const pool = require("./db");

const app = express();
app.use(cors());
app.use(express.json());

// Rotas
app.use("/api/auth", require("./routes/auth"));
app.use("/api/posts", require("./routes/posts"));
app.use("/api/doubts", require("./routes/doubts"));
app.use("/api", require("./routes/account")); // /api/dashboard e /api/profile

app.get("/", (req, res) => res.json({ servico: "VIDA TEA - API do painel", ok: true }));

const PORT = process.env.PORT || 3001;

// Cria um administrador padrao no primeiro uso, se ainda nao existir nenhum.
async function garantirAdminPadrao() {
  try {
    const [linhas] = await pool.query("SELECT COUNT(*) AS total FROM administradores");
    if (linhas[0].total > 0) return;
    const nome = process.env.ADMIN_NOME || "Equipe VIDA TEA";
    const email = process.env.ADMIN_EMAIL || "admin@vidatea.com";
    const senha = process.env.ADMIN_SENHA || "vidatea123";
    const hash = await bcrypt.hash(senha, 10);
    await pool.query(
      "INSERT INTO administradores (nome, email, senha_hash) VALUES (?, ?, ?)",
      [nome, email, hash]
    );
    console.log("--------------------------------------------------");
    console.log("Administrador padrao criado:");
    console.log("  E-mail:", email);
    console.log("  Senha :", senha);
    console.log("Troque a senha na tela de Configuracoes apos entrar.");
    console.log("--------------------------------------------------");
  } catch (e) {
    console.error("Aviso: nao foi possivel verificar/criar o admin padrao.");
    console.error("Confira se o banco foi criado (schema.sql) e o .env esta correto.");
    console.error(e.message);
  }
}

app.listen(PORT, async () => {
  await garantirAdminPadrao();
  console.log(`API do VIDA TEA rodando em http://localhost:${PORT}`);
});
