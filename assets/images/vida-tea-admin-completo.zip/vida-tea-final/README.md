# VIDA TEA — Painel administrativo (web)

Painel web de uso restrito à equipe do projeto VIDA TEA. Por aqui os
administradores fazem login, publicam conteúdos (que aparecem na Central de
Informações do aplicativo), respondem às dúvidas enviadas pelas famílias e
atualizam o próprio perfil.

> **Importante:** este projeto é **autossuficiente** — ele roda sozinho, com seu
> próprio backend e banco. Ele foi feito para depois ser **integrado** à parte do
> aplicativo que o restante do grupo está desenvolvendo (compartilhando o mesmo
> banco MySQL e a mesma API em Node.js).

## Tecnologias
- **Frontend:** React + Vite
- **Backend (produção):** Node.js + Express + MySQL
- **Backend (desenvolvimento local):** Python + Flask + SQLite *(sem instalação extra)*
- **Autenticação:** login por e-mail e senha (senha protegida com hash; token JWT)

---

## ▶️ Opção A — Rodar localmente (Python + SQLite, mais fácil)

Não precisa instalar MySQL nem Node.js no backend.

### Requisitos
- Python 3.8 ou superior
- Node.js 18 ou superior (só para o frontend)

### Passo 1 — Instalar dependências Python
```bash
pip install flask PyJWT werkzeug
```

### Passo 2 — Iniciar tudo de uma vez
```bash
chmod +x iniciar.sh
./iniciar.sh
```

Ou manualmente, em dois terminais:

**Terminal 1 — backend:**
```bash
PORT=8080 python3 backend/server_python.py
```

**Terminal 2 — frontend:**
```bash
cd frontend
npm install
npm run dev
```

Abra **http://localhost:5173** e faça login:
- **E-mail:** admin@vidatea.com
- **Senha:** vidatea123

---

## ▶️ Opção B — Rodar com MySQL (produção / integração com o app)

### Requisitos
- Node.js 18 ou superior
- MySQL (servidor) — ex.: MySQL Community Server / XAMPP

### Passo 1 — Criar o banco de dados
```bash
mysql -u root -p < backend/schema.sql
```

### Passo 2 — Configurar o .env
```bash
cd backend
cp .env.example .env
# abra o .env e ajuste DB_USER / DB_PASSWORD
```

### Passo 3 — Subir o backend
```bash
cd backend
npm install
npm start
```

### Passo 4 — Ajustar o proxy do frontend para porta 3001
Edite `frontend/vite.config.js` e mude `8080` → `3001`.

### Passo 5 — Subir o frontend
```bash
cd frontend
npm install
npm run dev
```

---

## Rotas da API

| Método | Rota                          | Auth? | Descrição                              |
|--------|-------------------------------|-------|----------------------------------------|
| POST   | /api/auth/login               | Não   | Fazer login                            |
| GET    | /api/posts/publicas           | **Não** | **Postagens para o app (sem login)** |
| GET    | /api/posts                    | Sim   | Listar/buscar postagens                |
| POST   | /api/posts                    | Sim   | Criar postagem                         |
| PUT    | /api/posts/:id                | Sim   | Editar postagem                        |
| DELETE | /api/posts/:id                | Sim   | Excluir postagem                       |
| GET    | /api/doubts                   | Sim   | Listar dúvidas                         |
| POST   | /api/doubts                   | **Não** | **App envia dúvida (sem login)**     |
| POST   | /api/doubts/:id/responder     | Sim   | Responder dúvida                       |
| GET    | /api/dashboard                | Sim   | Indicadores do painel                  |
| PUT    | /api/profile                  | Sim   | Atualizar perfil/senha                 |

### Como o app das famílias consome a API

**Exibir postagens (Central de Informações):**
```
GET http://SEU_SERVIDOR/api/posts/publicas
```

**Enviar uma dúvida:**
```
POST http://SEU_SERVIDOR/api/doubts
Content-Type: application/json

{ "usuario_nome": "Maria", "usuario_email": "maria@email.com", "mensagem": "Minha pergunta..." }
```

---

## Estrutura de pastas
```
vida-tea-admin/
├─ iniciar.sh            Script de inicialização rápida (Linux/Mac)
├─ backend/              API em Node.js + Express (produção com MySQL)
│  ├─ routes/            auth, posts (+ rota pública), doubts, account
│  ├─ schema.sql         Script do banco MySQL
│  ├─ server.js          Servidor Node.js
│  └─ server_python.py   Servidor alternativo Python/Flask (SQLite local)
└─ frontend/             Painel em React + Vite
   └─ src/pages/         Login, Dashboard, Postagens, Editor, Dúvidas, Config.
```

## Casos de uso cobertos
- UC001/UC002 — Acessar o sistema e fazer login
- UC003 — Fazer postagem
- UC004 — Responder dúvidas
- UC005 — Editar/excluir publicações
- UC006 — Buscar informações (busca por título)
- UC007 — Fazer atualizações (perfil e senha)

## Banco de dados (tabelas)
| Tabela            | Descrição                                      |
|-------------------|------------------------------------------------|
| administradores   | Membros da equipe que acessam o painel         |
| postagens         | Conteúdos publicados na Central de Informações |
| duvidas           | Perguntas enviadas pelas famílias pelo app     |

> Se o grupo já tiver um backend/banco próprio no app (Node, Python, Firebase,
> etc.), informe a tecnologia e as tabelas — o painel pode ser adaptado para usar
> o mesmo banco em vez de manter dois separados.
