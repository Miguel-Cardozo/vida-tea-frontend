#!/bin/bash
# ============================================================
#  VIDA TEA — Script de inicialização rápida
#  Sobe o backend Python (Flask + SQLite) na porta 8080
#  e o frontend React (Vite) na porta 5173.
#
#  Uso:
#    chmod +x iniciar.sh
#    ./iniciar.sh
# ============================================================

echo ""
echo "======================================"
echo "  VIDA TEA - Painel Administrativo"
echo "======================================"
echo ""

# Verifica se Python 3 está disponível
if ! command -v python3 &>/dev/null; then
  echo "❌ Python 3 não encontrado. Instale Python 3.8+ e tente novamente."
  exit 1
fi

# Verifica se Flask está instalado
if ! python3 -c "import flask" 2>/dev/null; then
  echo "📦 Instalando Flask..."
  pip install flask PyJWT werkzeug
fi

# Inicia o backend
echo "🚀 Iniciando backend (Flask + SQLite) na porta 8080..."
PORT=8080 python3 "$(dirname "$0")/backend/server_python.py" &
BACKEND_PID=$!
sleep 2

# Verifica se o backend está respondendo
if curl -s http://localhost:8080/ > /dev/null 2>&1; then
  echo "✅ Backend online em http://localhost:8080"
else
  echo "⚠️  Backend pode estar iniciando ainda..."
fi

# Instala dependências do frontend, se necessário
cd "$(dirname "$0")/frontend"
if [ ! -d "node_modules" ]; then
  echo "📦 Instalando dependências do frontend..."
  npm install
fi

echo ""
echo "🌐 Iniciando frontend (Vite) na porta 5173..."
echo "   Abra http://localhost:5173 no navegador"
echo "   Login: admin@vidatea.com | Senha: vidatea123"
echo ""
echo "   Pressione Ctrl+C para encerrar tudo."
echo ""

# Inicia o frontend (em foreground para capturar Ctrl+C)
npm run dev

# Ao sair, mata o backend também
kill $BACKEND_PID 2>/dev/null
echo "Servidores encerrados."
