import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { api } from "../api";

export default function PostEditor() {
  const { id } = useParams();
  const editando = Boolean(id);
  const navigate = useNavigate();

  const [form, setForm] = useState({ titulo: "", conteudo: "", tipo: "TEXTO", url_midia: "" });
  const [erro, setErro] = useState("");
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    if (editando) {
      api
        .get(`/posts/${id}`)
        .then((p) =>
          setForm({
            titulo: p.titulo || "",
            conteudo: p.conteudo || "",
            tipo: p.tipo || "TEXTO",
            url_midia: p.url_midia || "",
          })
        )
        .catch((e) => setErro(e.message));
    }
  }, [id]);

  function muda(campo, valor) {
    setForm((f) => ({ ...f, [campo]: valor }));
  }

  async function salvar(e) {
    e.preventDefault();
    setErro("");
    setSalvando(true);
    try {
      if (editando) await api.put(`/posts/${id}`, form);
      else await api.post("/posts", form);
      navigate("/postagens");
    } catch (err) {
      setErro(err.message);
    } finally {
      setSalvando(false);
    }
  }

  return (
    <>
      <div className="barra-topo">
        <h1>{editando ? "Editar postagem" : "Nova postagem"}</h1>
      </div>

      <form className="card" onSubmit={salvar} style={{ maxWidth: 680 }}>
        <div className="campo">
          <label htmlFor="titulo">Título</label>
          <input id="titulo" value={form.titulo} onChange={(e) => muda("titulo", e.target.value)} required />
        </div>

        <div className="campo">
          <label htmlFor="tipo">Tipo de conteúdo</label>
          <select id="tipo" value={form.tipo} onChange={(e) => muda("tipo", e.target.value)}>
            <option value="TEXTO">Texto</option>
            <option value="PDF">PDF</option>
            <option value="VIDEO">Vídeo</option>
          </select>
        </div>

        {form.tipo !== "TEXTO" && (
          <div className="campo">
            <label htmlFor="url">Link do {form.tipo === "PDF" ? "PDF" : "vídeo"}</label>
            <input
              id="url"
              placeholder="https://..."
              value={form.url_midia}
              onChange={(e) => muda("url_midia", e.target.value)}
            />
          </div>
        )}

        <div className="campo">
          <label htmlFor="conteudo">Conteúdo</label>
          <textarea id="conteudo" rows={9} value={form.conteudo} onChange={(e) => muda("conteudo", e.target.value)} required />
        </div>

        {erro && <p className="erro">{erro}</p>}

        <div className="acoes">
          <button className="btn" type="submit" disabled={salvando}>
            {salvando ? "Salvando..." : editando ? "Salvar edição" : "Publicar"}
          </button>
          <button className="btn btn-secundario" type="button" onClick={() => navigate("/postagens")}>
            Cancelar
          </button>
        </div>
      </form>
    </>
  );
}
