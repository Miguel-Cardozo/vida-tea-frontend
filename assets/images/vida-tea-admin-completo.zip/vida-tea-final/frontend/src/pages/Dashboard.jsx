import { useEffect, useState } from "react";
import { useOutletContext } from "react-router-dom";
import { api } from "../api";
import { useAuth } from "../context/Auth";

const cores = { TEXTO: "var(--azul)", PDF: "var(--rosa)", VIDEO: "var(--amarelo)" };

export default function Dashboard() {
  const { admin } = useAuth();
  const { iniciais } = useOutletContext();
  const [dados, setDados] = useState(null);
  const [erro, setErro] = useState("");

  useEffect(() => {
    api.get("/dashboard").then(setDados).catch((e) => setErro(e.message));
  }, []);

  return (
    <>
      <div className="barra-topo">
        <h1>Painel</h1>
        <div className="usuario">
          <span>{admin?.nome}</span>
          <span className="avatar">{iniciais}</span>
        </div>
      </div>

      {erro && <p className="erro">{erro}</p>}

      {dados && (
        <>
          <div className="grade-stats">
            <div className="card stat">
              <div className="barra-cor" style={{ background: "var(--azul)" }} />
              <div className="num">{dados.postagens}</div>
              <div className="rotulo">Postagens publicadas</div>
            </div>
            <div className="card stat">
              <div className="barra-cor" style={{ background: "var(--amarelo)" }} />
              <div className="num">{dados.duvidasPendentes}</div>
              <div className="rotulo">Dúvidas pendentes</div>
            </div>
            <div className="card stat">
              <div className="barra-cor" style={{ background: "var(--verde)" }} />
              <div className="num">{dados.duvidasRespondidas}</div>
              <div className="rotulo">Dúvidas respondidas</div>
            </div>
            <div className="card stat">
              <div className="barra-cor" style={{ background: "var(--rosa)" }} />
              <div className="num">{dados.administradores}</div>
              <div className="rotulo">Administradores</div>
            </div>
          </div>

          <div className="card" style={{ marginTop: 20 }}>
            <h3 style={{ marginTop: 0 }}>Postagens por tipo</h3>
            {dados.postagensPorTipo.length === 0 && (
              <p className="vazio">Nenhuma postagem ainda. Crie a primeira em “Postagens”.</p>
            )}
            {dados.postagensPorTipo.map((t) => (
              <div key={t.tipo} style={{ marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14 }}>
                  <span>{t.tipo}</span>
                  <span>{t.total}</span>
                </div>
                <div style={{ height: 8, background: "#eef4f9", borderRadius: 6 }}>
                  <div
                    style={{
                      height: "100%",
                      width: `${Math.min(100, (t.total / Math.max(1, dados.postagens)) * 100)}%`,
                      background: cores[t.tipo] || "var(--azul)",
                      borderRadius: 6,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  );
}
