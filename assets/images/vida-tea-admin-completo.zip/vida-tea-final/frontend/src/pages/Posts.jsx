import { useEffect, useState } from "react";
import { Link, useNavigate, useOutletContext } from "react-router-dom";
import { api } from "../api";

const tagClasse = { PDF: "tag tag-pdf", VIDEO: "tag tag-video", TEXTO: "tag tag-texto" };

export default function Posts() {
  const { iniciais } = useOutletContext();
  const navigate = useNavigate();
  const [lista, setLista] = useState([]);
  const [busca, setBusca] = useState("");
  const [erro, setErro] = useState("");

  function carregar(termo = "") {
    api
      .get("/posts" + (termo ? `?busca=${encodeURIComponent(termo)}` : ""))
      .then(setLista)
      .catch((e) => setErro(e.message));
  }

  useEffect(() => {
    carregar();
  }, []);

  async function excluir(id) {
    if (!confirm("Excluir esta postagem? Esta ação não pode ser desfeita.")) return;
    try {
      await api.del(`/posts/${id}`);
      carregar(busca);
    } catch (e) {
      setErro(e.message);
    }
  }

  return (
    <>
      <div className="barra-topo">
        <h1>Postagens</h1>
        <Link className="btn" to="/postagens/nova">+ Nova postagem</Link>
      </div>

      <div className="card">
        <div className="toolbar">
          <input
            className="busca"
            placeholder="Buscar pelo título..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && carregar(busca)}
          />
          <button className="btn btn-secundario" onClick={() => carregar(busca)}>Buscar</button>
        </div>

        {erro && <p className="erro">{erro}</p>}

        {lista.length === 0 ? (
          <p className="vazio">Nenhuma postagem encontrada.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Título</th>
                <th>Tipo</th>
                <th>Publicado em</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {lista.map((p) => (
                <tr key={p.id}>
                  <td>{p.titulo}</td>
                  <td><span className={tagClasse[p.tipo]}>{p.tipo}</span></td>
                  <td>{new Date(p.publicado_em).toLocaleDateString("pt-BR")}</td>
                  <td>
                    <div className="acoes">
                      <button className="btn btn-secundario btn-pequeno" onClick={() => navigate(`/postagens/${p.id}`)}>Editar</button>
                      <button className="btn btn-perigo btn-pequeno" onClick={() => excluir(p.id)}>Excluir</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
