import { useEffect, useState } from "react";
import { api } from "../api";

export default function Doubts() {
  const [lista, setLista] = useState([]);
  const [respostas, setRespostas] = useState({});
  const [erro, setErro] = useState("");
  const [filtro, setFiltro] = useState("todas");

  function carregar() {
    const q = filtro === "todas" ? "" : `?status=${filtro}`;
    api.get("/doubts" + q).then(setLista).catch((e) => setErro(e.message));
  }

  useEffect(() => {
    carregar();
  }, [filtro]);

  async function responder(id) {
    const texto = (respostas[id] || "").trim();
    if (!texto) return;
    try {
      await api.post(`/doubts/${id}/responder`, { resposta: texto });
      setRespostas((r) => ({ ...r, [id]: "" }));
      carregar();
    } catch (e) {
      setErro(e.message);
    }
  }

  return (
    <>
      <div className="barra-topo">
        <h1>Dúvidas e mensagens</h1>
        <select value={filtro} onChange={(e) => setFiltro(e.target.value)} style={{ width: 200 }}>
          <option value="todas">Todas</option>
          <option value="pendente">Pendentes</option>
          <option value="respondida">Respondidas</option>
        </select>
      </div>

      <div className="card">
        {erro && <p className="erro">{erro}</p>}
        {lista.length === 0 ? (
          <p className="vazio">Nenhuma mensagem por aqui.</p>
        ) : (
          lista.map((d) => (
            <div className="duvida" key={d.id}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                <span className="quem">{d.usuario_nome}</span>
                <span className={"tag " + (d.status === "pendente" ? "tag-pendente" : "tag-respondida")}>
                  {d.status === "pendente" ? "Pendente" : "Respondida"}
                </span>
              </div>
              <p className="msg">{d.mensagem}</p>

              {d.status === "respondida" ? (
                <div style={{ background: "#f3f9f4", padding: 12, borderRadius: 10 }}>
                  <strong>Resposta:</strong> {d.resposta}
                </div>
              ) : (
                <div className="resp-area">
                  <textarea
                    rows={3}
                    placeholder="Escreva a resposta..."
                    value={respostas[d.id] || ""}
                    onChange={(e) => setRespostas((r) => ({ ...r, [d.id]: e.target.value }))}
                  />
                  <button className="btn btn-pequeno" style={{ marginTop: 8 }} onClick={() => responder(d.id)}>
                    Enviar resposta
                  </button>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </>
  );
}
