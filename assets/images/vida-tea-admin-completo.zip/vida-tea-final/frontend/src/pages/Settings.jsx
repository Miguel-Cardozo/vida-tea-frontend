import { useState } from "react";
import { api } from "../api";
import { useAuth } from "../context/Auth";

export default function Settings() {
  const { admin, atualizarAdmin } = useAuth();
  const [form, setForm] = useState({
    nome: admin?.nome || "",
    email: admin?.email || "",
    senhaAtual: "",
    novaSenha: "",
  });
  const [erro, setErro] = useState("");
  const [ok, setOk] = useState("");

  function muda(c, v) {
    setForm((f) => ({ ...f, [c]: v }));
  }

  async function salvar(e) {
    e.preventDefault();
    setErro("");
    setOk("");
    try {
      await api.put("/profile", form);
      atualizarAdmin({ nome: form.nome, email: form.email });
      setOk("Alterações salvas com sucesso.");
      setForm((f) => ({ ...f, senhaAtual: "", novaSenha: "" }));
    } catch (err) {
      setErro(err.message);
    }
  }

  return (
    <>
      <div className="barra-topo">
        <h1>Configurações</h1>
      </div>

      <form className="card" onSubmit={salvar} style={{ maxWidth: 560 }}>
        <h3 style={{ marginTop: 0 }}>Meu perfil</h3>
        <div className="campo">
          <label htmlFor="nome">Nome</label>
          <input id="nome" value={form.nome} onChange={(e) => muda("nome", e.target.value)} />
        </div>
        <div className="campo">
          <label htmlFor="email">E-mail</label>
          <input id="email" type="email" value={form.email} onChange={(e) => muda("email", e.target.value)} />
        </div>

        <h3>Alterar senha</h3>
        <p style={{ color: "var(--cinza)", marginTop: 0, fontSize: 14 }}>
          Preencha apenas se quiser trocar a senha.
        </p>
        <div className="campo">
          <label htmlFor="atual">Senha atual</label>
          <input id="atual" type="password" autoComplete="current-password"
            value={form.senhaAtual} onChange={(e) => muda("senhaAtual", e.target.value)} />
        </div>
        <div className="campo">
          <label htmlFor="nova">Nova senha</label>
          <input id="nova" type="password" autoComplete="new-password"
            value={form.novaSenha} onChange={(e) => muda("novaSenha", e.target.value)} />
        </div>

        {erro && <p className="erro">{erro}</p>}
        {ok && <p className="aviso-sucesso">{ok}</p>}

        <button className="btn" type="submit">Salvar alterações</button>
      </form>
    </>
  );
}
