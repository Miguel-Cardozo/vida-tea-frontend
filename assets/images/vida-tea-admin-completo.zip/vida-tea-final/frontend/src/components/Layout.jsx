import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../context/Auth";
import Logo from "./Logo";

const itens = [
  { para: "/", rotulo: "Painel", ic: "📊" },
  { para: "/postagens", rotulo: "Postagens", ic: "📝" },
  { para: "/duvidas", rotulo: "Dúvidas", ic: "💬" },
  { para: "/configuracoes", rotulo: "Configurações", ic: "⚙" },
];

export default function Layout() {
  const { admin, sair } = useAuth();
  const navigate = useNavigate();

  function logout() {
    sair();
    navigate("/login");
  }

  const iniciais = (admin?.nome || "?")
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="topo">
          <Logo />
        </div>
        {itens.map((it) => (
          <NavLink
            key={it.para}
            to={it.para}
            end={it.para === "/"}
            className={({ isActive }) => "nav-item" + (isActive ? " ativo" : "")}
          >
            <span className="ic" aria-hidden="true">{it.ic}</span>
            <span className="rotulo-nav">{it.rotulo}</span>
          </NavLink>
        ))}
        <div className="rodape">
          <button className="nav-item" onClick={logout} style={{ width: "100%", background: "none" }}>
            <span className="ic" aria-hidden="true">⏻</span>
            <span className="rotulo-nav">Sair</span>
          </button>
        </div>
      </aside>

      <main className="conteudo">
        <Outlet context={{ iniciais }} />
      </main>
    </div>
  );
}
