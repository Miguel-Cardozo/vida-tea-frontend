export default function Logo({ size = 22 }) {
  return (
    <span className="marca" style={{ fontSize: size }} aria-label="VIDA TEA">
      <span className="v">V</span>
      <span className="i">I</span>
      <span className="d">D</span>
      <span className="a">A</span>
      <span className="txt">&nbsp;</span>
      <span className="tea">TEA</span>
    </span>
  );
}
