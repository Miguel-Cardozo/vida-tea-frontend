import React from "react";
import { createRoot } from "react-dom/client";
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  useLocation,
} from "react-router-dom";
import { AuthProvider, useAuth } from "./context/Auth";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Posts from "./pages/Posts";
import PostEditor from "./pages/PostEditor";
import Doubts from "./pages/Doubts";
import Settings from "./pages/Settings";
import "./styles.css";

function Protegida({ children }) {
  const { admin } = useAuth();
  const location = useLocation();
  if (!admin) return <Navigate to="/login" state={{ from: location }} replace />;
  return children;
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            element={
              <Protegida>
                <Layout />
              </Protegida>
            }
          >
            <Route path="/" element={<Dashboard />} />
            <Route path="/postagens" element={<Posts />} />
            <Route path="/postagens/nova" element={<PostEditor />} />
            <Route path="/postagens/:id" element={<PostEditor />} />
            <Route path="/duvidas" element={<Doubts />} />
            <Route path="/configuracoes" element={<Settings />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

createRoot(document.getElementById("root")).render(<App />);
