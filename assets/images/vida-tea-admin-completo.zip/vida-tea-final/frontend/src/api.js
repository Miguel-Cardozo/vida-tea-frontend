// Camada simples de comunicacao com a API.
const BASE = import.meta.env.VITE_API_URL || "/api";

function getToken() {
  return localStorage.getItem("vt_token");
}

async function req(caminho, opcoes = {}) {
  const headers = { "Content-Type": "application/json", ...(opcoes.headers || {}) };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const resp = await fetch(BASE + caminho, { ...opcoes, headers });
  let dados = null;
  try {
    dados = await resp.json();
  } catch (_) {
    dados = null;
  }
  if (!resp.ok) {
    throw new Error((dados && dados.erro) || "Erro ao comunicar com o servidor.");
  }
  return dados;
}

export const api = {
  get: (c) => req(c),
  post: (c, corpo) => req(c, { method: "POST", body: JSON.stringify(corpo) }),
  put: (c, corpo) => req(c, { method: "PUT", body: JSON.stringify(corpo) }),
  del: (c) => req(c, { method: "DELETE" }),
};
