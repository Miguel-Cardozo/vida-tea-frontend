import { createContext, useContext, useState } from "react";
import { api } from "../api";

const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
  const [admin, setAdmin] = useState(() => {
    const salvo = localStorage.getItem("vt_admin");
    return salvo ? JSON.parse(salvo) : null;
  });

  async function entrar(email, senha) {
    const dados = await api.post("/auth/login", { email, senha });
    localStorage.setItem("vt_token", dados.token);
    localStorage.setItem("vt_admin", JSON.stringify(dados.admin));
    setAdmin(dados.admin);
  }

  function sair() {
    localStorage.removeItem("vt_token");
    localStorage.removeItem("vt_admin");
    setAdmin(null);
  }

  function atualizarAdmin(novo) {
    const merge = { ...admin, ...novo };
    localStorage.setItem("vt_admin", JSON.stringify(merge));
    setAdmin(merge);
  }

  return (
    <AuthCtx.Provider value={{ admin, entrar, sair, atualizarAdmin }}>
      {children}
    </AuthCtx.Provider>
  );
}

export function useAuth() {
  return useContext(AuthCtx);
}
