import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// O proxy encaminha as chamadas /api para o backend.
// Porta 8080 é usada quando o backend roda com Python/Flask localmente.
// Se rodar o Node.js original (MySQL), mude de volta para 3001.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": "http://localhost:8080",
    },
  },
});
