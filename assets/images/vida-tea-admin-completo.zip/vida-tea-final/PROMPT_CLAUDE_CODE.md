# Prompt para o Claude Code

Cole o texto abaixo no Claude Code, **dentro da pasta `vida-tea-admin`**, para
continuar o desenvolvimento e integrar com a parte do aplicativo do grupo.

---

Você está na pasta de um projeto chamado VIDA TEA, um sistema de apoio a famílias
de crianças com Transtorno do Espectro Autista (TEA). Esta pasta contém o
**painel administrativo web** já estruturado:

- `backend/` — API em Node.js + Express + MySQL (rotas em `routes/`: auth, posts,
  doubts, account; conexão em `db.js`; banco em `schema.sql`; entrada em `server.js`).
- `frontend/` — painel em React + Vite (páginas em `src/pages/`: Login, Dashboard,
  Posts, PostEditor, Doubts, Settings; comunicação com a API em `src/api.js`).

O painel cobre os casos de uso UC001 a UC007 (login, fazer postagem, responder
dúvidas, editar/excluir publicações, buscar postagens e atualizar perfil).

Quero que você:

1. Leia o `README.md` e todo o código para entender a estrutura atual.
2. Rode o projeto localmente (instale dependências do `backend` e do `frontend`,
   confira o `.env`, suba os dois) e corrija qualquer erro que impedir a execução.
3. Garanta que o fluxo completo funcione: login → ver dashboard → criar, editar,
   buscar e excluir postagens → responder dúvidas → atualizar perfil/senha.
4. Adicione uma rota pública de leitura `GET /api/posts/publicas` (sem login) para
   o aplicativo mobile consumir as postagens da Central de Informações.
5. Mantenha o mesmo estilo visual (cores e fontes em `frontend/src/styles.css`) e
   escreva comentários em português, de forma simples.

Antes de mudar algo grande, me explique o plano. Não exclua dados nem altere o
`schema.sql` sem avisar. Trabalhe em passos pequenos e testáveis.

> Se o grupo já tiver um backend/banco próprio do aplicativo, me informe a
> tecnologia e as tabelas existentes para que eu adapte o painel a esse banco em
> vez de criar um separado.
